var DATA = {    
    
}

export default DATA